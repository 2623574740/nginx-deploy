# 消息函数，1-执行结果，2-失败消息，3-成功消息
Message(){
	if [ ${1} -ne 0 ]
	then
		echo ${2}
		exit
	else
		echo ${3}
	fi	
}
# 安装必要依赖
yum -y install make zlib zlib-devel gcc-c++ libtool  openssl openssl-devel >> nginx.log
# 解压pcre
echo 开始解压pcre
tar xzvf ./pcre-8.00.tar.gz >> nginx.log
Message $? "解压失败" "解压成功"

# 解压nginx
echo 开始解压nginx...
tar xzvf ./nginx-1.20.1.tar.gz >> nginx.log
Message $? "解压失败" "解压成功"

i=`find / -maxdepth 1 -name server | wc -l`
if [ ${i} -eq 0 ]
then
	echo "根目录下无server目录，现在开始创建..."
	mkdir /server
	if [ $? -eq 0 ]
	then
		echo "创建成功"
	else
		echo "创建失败"
	fi
fi
# 移动
mv pcre-8.00 /server/
Message $? "移动pcre失败" "移动pcre成功"
mv nginx-1.20.1 /server/
Message $? "移动nginx失败" "移动nginx成功"
# 安装pcre
cd /server/pcre-8.00
echo "pcre-8.00 开始配置"
./configure >> ~/nginx.log
Message $? "配置失败" "配置成功"
echo "pcre-8.00 开始编译，安装"

make >> ~/nginx.log
make install >> ~/nginx.log
Message $? "安装失败" "安装成功"
# 安装nginx
cd /server/nginx-1.20.1
echo "nginx-1.20.1 开始配置"
./configure --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module --with-pcre=/server/pcre-8.00 >> ~/nginx.log
Message $? "配置失败" "配置成功"
make >> ~/nginx.log
make install >> ~/nginx.log
Message $? "安装失败" "安装成功"
cd ~
echo "删除日志文件"
rm -f ./nginx.log
echo "结束"
